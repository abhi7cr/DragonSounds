"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var http_1 = require('@angular/http');
//import { HERO } from './hero';
//import { HEROES } from './mock-heroes';
require('rxjs/add/operator/toPromise');
var HeroService = (function () {
    function HeroService(http, jsonp) {
        this.http = http;
        this.jsonp = jsonp;
        this.code = '';
        this.state = '';
        this.spotifySearchUrl = 'https://api.spotify.com/v1/search?';
        this.spotifyAlbumUrl = 'https://api.spotify.com/v1/albums/';
        this.spotifyPlaylistUrl = 'https://api.spotify.com/v1/playlists/';
        this.client_id = "0bfbd70607c94e12b1e5863b2cbc9b2b";
        this.client_secret = "1a5c8cbfa0ff4229bc9ff3502759c242";
        this.scope = 'user-read-private user-read-email';
        this.redirect_uri = "http://localhost:3000/dashboard";
        this.form = {};
        this.jsonp = jsonp;
        if (window.location.search.indexOf('code') === 1) {
            this.code = window.location.search.split('&')[0].substring(1).split('=')[1];
            this.state = window.location.search.split('&')[1].split('=')[1];
            this.getToken();
        }
    }
    //getToken();
    HeroService.prototype.handleError = function (error) {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    };
    HeroService.prototype.parseResponse = function (response) {
        return response;
    };
    HeroService.prototype.getAlbums = function (query) {
        return this.http.get(this.spotifySearchUrl + 'q=' + query + '&type=album')
            .toPromise()
            .then(this.parseResponse)
            .catch(this.handleError);
    };
    HeroService.prototype.getTracks = function (id) {
        var _this = this;
        return this.http.get(this.spotifyAlbumUrl + id)
            .toPromise()
            .then(function (response) { return _this.parseResponse(response); })
            .catch(this.handleError);
    };
    HeroService.prototype.getPlaylists = function (query) {
        return this.http.get(this.spotifySearchUrl + 'q=' + query + '&type=playlist')
            .toPromise()
            .then(this.parseResponse)
            .catch(this.handleError);
    };
    HeroService.prototype.getTracksOfPlaylist = function (id) {
        var _this = this;
        return this.http.get(this.spotifyPlaylistUrl + id)
            .toPromise()
            .then(function (response) { return _this.parseResponse(response); })
            .catch(this.handleError);
    };
    HeroService.prototype.generateRandomString = function (length) {
        var text = '';
        var possible = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        for (var i = 0; i < length; i++) {
            text += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return text;
    };
    HeroService.prototype.login = function () {
        window.location.href = 'https://accounts.spotify.com/authorize?response_type=code'
            + '&client_id=' + this.client_id + '&scope=' + this.scope +
            '&redirect_uri=' + this.redirect_uri + '&state=' + this.generateRandomString(16);
    };
    HeroService.prototype.getToken = function () {
        var _this = this;
        var _headers = new http_1.Headers();
        //_headers.append('Authorization', 'Basic ' + (new NodeBuffer(this.client_id + ':' + 
        // this.client_secret).toString('base64'));
        _headers.append('Content-Type', 'application/json; charset=utf-8');
        _headers.append('Accept', 'application/json');
        this.form = {
            code: this.code,
            redirect_uri: this.redirect_uri,
            grant_type: 'authorization_code',
            withCredentials: true,
            json: true
        };
        return this.http.get('http://localhost:3000/callback?code=' + this.code)
            .toPromise()
            .then(function (response) { return _this.parseResponse(response); })
            .catch(this.handleError);
    };
    HeroService = __decorate([
        core_1.Injectable(), 
        __metadata('design:paramtypes', [http_1.Http, http_1.Jsonp])
    ], HeroService);
    return HeroService;
}());
exports.HeroService = HeroService;
//# sourceMappingURL=hero.service.js.map