export class SpotifyService {
	
}