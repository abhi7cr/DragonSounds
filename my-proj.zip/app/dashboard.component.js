"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var hero_service_1 = require('./hero.service');
var router_deprecated_1 = require('@angular/router-deprecated');
var DashboardComponent = (function () {
    function DashboardComponent(heroService, router) {
        this.heroService = heroService;
        this.router = router;
        this.albums = [];
        this.query = "";
        this.playlists = [];
        this.playlistName = '';
        this.showAlbums = true;
        this.tracks = [];
    }
    DashboardComponent.prototype.parseAlbums = function (response) {
        this.albums = response.json().albums.items;
    };
    DashboardComponent.prototype.parseTracks = function (response) {
        this.tracks = response.json().tracks.items;
        this.showAlbums = false;
    };
    DashboardComponent.prototype.parsePlaylists = function (response) {
        this.playlists = response.json().playlists.items;
    };
    DashboardComponent.prototype.showAlbum = function () {
        this.showAlbums = true;
    };
    DashboardComponent.prototype.handleError = function (error) {
        console.error('An error occurred', error);
        return (error.message || error);
    };
    DashboardComponent.prototype.fetchAlbums = function () {
        var _this = this;
        this.heroService.getAlbums(this.query)
            .then(function (res) { return _this.parseAlbums(res); })
            .catch(this.handleError);
    };
    DashboardComponent.prototype.fetchPlaylists = function () {
        var _this = this;
        this.heroService.getPlaylists(this.playlistName)
            .then(function (res) { return _this.parsePlaylists(res); })
            .catch(this.handleError);
    };
    DashboardComponent.prototype.getTracks = function (album) {
        var _this = this;
        this.heroService.getTracks(album.id)
            .then(function (res) { return _this.parseTracks(res); });
    };
    DashboardComponent.prototype.getTracksOfPlaylist = function (playlist) {
        var _this = this;
        this.heroService.getTracksOfPlaylist(playlist.id)
            .then(function (res) { return _this.parseTracks(res); });
    };
    DashboardComponent.prototype.login = function () {
        this.heroService.login();
    };
    DashboardComponent = __decorate([
        core_1.Component({
            selector: 'my-dashboard',
            templateUrl: 'app/dashboard.component.html',
            styleUrls: ['app/dashboard.component.css']
        }), 
        __metadata('design:paramtypes', [hero_service_1.HeroService, router_deprecated_1.Router])
    ], DashboardComponent);
    return DashboardComponent;
}());
exports.DashboardComponent = DashboardComponent;
//# sourceMappingURL=dashboard.component.js.map