"use strict";
var SpotifyService = (function () {
    function SpotifyService() {
    }
    return SpotifyService;
}());
exports.SpotifyService = SpotifyService;
//# sourceMappingURL=spotify.service.js.map